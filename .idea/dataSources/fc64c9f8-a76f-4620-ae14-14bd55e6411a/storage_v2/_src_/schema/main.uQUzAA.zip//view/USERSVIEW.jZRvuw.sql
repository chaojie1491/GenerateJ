CREATE VIEW USERSVIEW AS
SELECT Doctors.id AS id, Doctors.Name AS name, Doctors.Password AS password FROM Doctors
UNION
SELECT FrontDeskUser.id AS id, FrontDeskUser.Name AS name, FrontDeskUser.Password AS password FROM FrontDeskUser
UNION
SELECT DepartmentSecretary.id AS id, DepartmentSecretary.Name AS name, DepartmentSecretary.Password AS password 
FROM DepartmentSecretary;

